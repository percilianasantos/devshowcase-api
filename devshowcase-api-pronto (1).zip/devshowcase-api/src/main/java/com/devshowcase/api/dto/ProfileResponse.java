package com.devshowcase.api.dto;

import com.devshowcase.api.entity.Profile;

public record ProfileResponse(Long id, String name, String email, String bio) {
    public static ProfileResponse from(Profile p) {
        return new ProfileResponse(p.getId(), p.getName(), p.getEmail(), p.getBio());
    }
}
