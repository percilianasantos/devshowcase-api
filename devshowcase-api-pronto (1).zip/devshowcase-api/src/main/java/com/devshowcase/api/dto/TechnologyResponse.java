package com.devshowcase.api.dto;

import com.devshowcase.api.entity.Technology;

public record TechnologyResponse(Long id, String name) {
    public static TechnologyResponse from(Technology t) {
        return new TechnologyResponse(t.getId(), t.getName());
    }
}
