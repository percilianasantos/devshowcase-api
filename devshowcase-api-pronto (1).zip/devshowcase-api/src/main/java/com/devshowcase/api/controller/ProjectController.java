package com.devshowcase.api.controller;

import com.devshowcase.api.dto.ProjectRequest;
import com.devshowcase.api.dto.ProjectResponse;
import com.devshowcase.api.entity.Project;
import com.devshowcase.api.repository.ProfileRepository;
import com.devshowcase.api.repository.ProjectRepository;
import com.devshowcase.api.repository.TechnologyRepository;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.HashSet;

@RestController
@RequestMapping("/api/projects")
public class ProjectController {
    private final ProjectRepository projectRepository;
    private final ProfileRepository profileRepository;
    private final TechnologyRepository technologyRepository;

    public ProjectController(ProjectRepository projectRepository,
                             ProfileRepository profileRepository,
                             TechnologyRepository technologyRepository) {
        this.projectRepository = projectRepository;
        this.profileRepository = profileRepository;
        this.technologyRepository = technologyRepository;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ProjectResponse create(@Valid @RequestBody ProjectRequest request) {
        var profile = profileRepository.findById(request.profileId())
            .orElseThrow(() -> new RuntimeException("Perfil não encontrado"));

        var technologies = technologyRepository.findAllById(
            request.technologyIds() == null ? java.util.Set.of() : request.technologyIds()
        );

        if (request.technologyIds() != null && technologies.size() != request.technologyIds().size()) {
            throw new RuntimeException("Uma ou mais tecnologias não foram encontradas");
        }

        Project project = new Project();
        project.setTitle(request.title());
        project.setDescription(request.description());
        project.setUrl(request.url());
        project.setProfile(profile);
        project.getTechnologies().addAll(new HashSet<>(technologies));

        return ProjectResponse.from(projectRepository.save(project));
    }

    @GetMapping
    public List<ProjectResponse> findAll() {
        return projectRepository.findAll().stream().map(ProjectResponse::from).toList();
    }
}
