package com.devshowcase.api.dto;

import com.devshowcase.api.entity.Project;
import java.util.Set;
import java.util.stream.Collectors;

public record ProjectResponse(
    Long id,
    String title,
    String description,
    String url,
    Long profileId,
    Set<TechnologyResponse> technologies
) {
    public static ProjectResponse from(Project p) {
        return new ProjectResponse(
            p.getId(),
            p.getTitle(),
            p.getDescription(),
            p.getUrl(),
            p.getProfile().getId(),
            p.getTechnologies().stream().map(TechnologyResponse::from).collect(Collectors.toSet())
        );
    }
}
