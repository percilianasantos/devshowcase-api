package com.devshowcase.api.controller;

import com.devshowcase.api.dto.ProfileRequest;
import com.devshowcase.api.dto.ProfileResponse;
import com.devshowcase.api.entity.Profile;
import com.devshowcase.api.repository.ProfileRepository;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/profiles")
public class ProfileController {
    private final ProfileRepository repository;

    public ProfileController(ProfileRepository repository) {
        this.repository = repository;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ProfileResponse create(@Valid @RequestBody ProfileRequest request) {
        Profile profile = new Profile(request.name(), request.email(), request.bio());
        return ProfileResponse.from(repository.save(profile));
    }

    @GetMapping("/{id}")
    public ProfileResponse findById(@PathVariable Long id) {
        Profile profile = repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Perfil não encontrado"));
        return ProfileResponse.from(profile);
    }
}
