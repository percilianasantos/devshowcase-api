package com.devshowcase.api.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.validation.constraints.Pattern;
import java.util.Set;

public record ProjectRequest(
    @NotBlank(message = "Título é obrigatório")
    String title,

    @NotBlank(message = "Descrição é obrigatória")
    String description,

    @NotBlank(message = "URL é obrigatória")
    @Pattern(regexp = "https?://.+", message = "URL deve começar com http:// ou https://")
    String url,

    @NotNull(message = "profileId é obrigatório")
    Long profileId,

    @Size(min = 1, message = "Informe pelo menos uma tecnologia")
    Set<Long> technologyIds
) {}
