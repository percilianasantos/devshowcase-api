package com.devshowcase.api.controller;

import com.devshowcase.api.dto.TechnologyRequest;
import com.devshowcase.api.dto.TechnologyResponse;
import com.devshowcase.api.entity.Technology;
import com.devshowcase.api.repository.TechnologyRepository;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/technologies")
public class TechnologyController {
    private final TechnologyRepository repository;

    public TechnologyController(TechnologyRepository repository) {
        this.repository = repository;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public TechnologyResponse create(@Valid @RequestBody TechnologyRequest request) {
        Technology technology = new Technology(request.name());
        return TechnologyResponse.from(repository.save(technology));
    }

    @GetMapping
    public List<TechnologyResponse> findAll() {
        return repository.findAll().stream().map(TechnologyResponse::from).toList();
    }
}
