package com.devshowcase.api.controller;

import com.devshowcase.api.entity.Feedback;
import com.devshowcase.api.repository.FeedbackRepository;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/feedbacks")
public class FeedbackController {
    private final FeedbackRepository repository;

    public FeedbackController(FeedbackRepository repository) {
        this.repository = repository;
    }

    @GetMapping("/health")
    public String health() {
        return "Feedback endpoint disponível";
    }
}
