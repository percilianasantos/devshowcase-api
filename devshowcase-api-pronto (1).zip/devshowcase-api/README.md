# DevShowcase API

Backend desenvolvido com Java e Spring Boot para a plataforma DevShowcase.

## Tecnologias
- Java 17
- Spring Boot 4.0.8
- Spring Web
- Spring Data JPA
- H2 Database
- Bean Validation

## Relacionamentos
- Profile 1:N Project
- Project N:N Technology
- Project 1:N Feedback

## Endpoints obrigatórios
- POST /api/profiles
- GET /api/profiles/{id}
- POST /api/technologies
- GET /api/technologies
- POST /api/projects
- GET /api/projects

## Banco H2
Console: http://localhost:8080/h2-console

JDBC URL: jdbc:h2:mem:devshowcase
Usuário: sa
Senha: (vazia)
