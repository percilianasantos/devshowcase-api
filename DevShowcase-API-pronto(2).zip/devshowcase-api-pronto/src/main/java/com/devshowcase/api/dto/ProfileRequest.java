package com.devshowcase.api.dto;
import jakarta.validation.constraints.*;
public record ProfileRequest(@NotBlank String name,@NotBlank @Email String email,String bio) {}