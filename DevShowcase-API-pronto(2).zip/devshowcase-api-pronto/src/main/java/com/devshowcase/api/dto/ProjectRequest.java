package com.devshowcase.api.dto;
import jakarta.validation.constraints.*;
import java.util.List;
public record ProjectRequest(@NotBlank String title,@NotBlank String description,@NotBlank @Pattern(regexp="https?://.+") String url,@NotNull Long profileId,List<Long> technologyIds) {}