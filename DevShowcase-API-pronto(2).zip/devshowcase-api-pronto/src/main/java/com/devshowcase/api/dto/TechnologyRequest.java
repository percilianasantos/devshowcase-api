package com.devshowcase.api.dto;
import jakarta.validation.constraints.NotBlank;
public record TechnologyRequest(@NotBlank String name) {}