package com.devshowcase.api.controller;
import com.devshowcase.api.dto.*; import com.devshowcase.api.entity.Technology; import com.devshowcase.api.repository.TechnologyRepository;
import jakarta.validation.Valid; import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/api/technologies")
public class TechnologyController {
 private final TechnologyRepository repo; public TechnologyController(TechnologyRepository repo){this.repo=repo;}
 @PostMapping @ResponseStatus(HttpStatus.CREATED) public TechnologyResponse create(@Valid @RequestBody TechnologyRequest r){Technology t=new Technology();t.setName(r.name());t=repo.save(t);return new TechnologyResponse(t.getId(),t.getName());}
 @GetMapping public List<TechnologyResponse> all(){return repo.findAll().stream().map(t->new TechnologyResponse(t.getId(),t.getName())).toList();}
}