package com.devshowcase.api.repository;
import com.devshowcase.api.entity.Technology;
import org.springframework.data.jpa.repository.JpaRepository;
public interface TechnologyRepository extends JpaRepository<Technology, Long> {}
