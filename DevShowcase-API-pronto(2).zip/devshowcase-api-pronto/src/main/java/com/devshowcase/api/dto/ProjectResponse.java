package com.devshowcase.api.dto;
import java.util.List;
public record ProjectResponse(Long id,String title,String description,String url,Long profileId,List<Long> technologyIds) {}