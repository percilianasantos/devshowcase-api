package com.devshowcase.api.dto;
public record ProfileResponse(Long id,String name,String email,String bio) {}