package com.devshowcase.api.repository;
import com.devshowcase.api.entity.Project;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ProjectRepository extends JpaRepository<Project, Long> {}
