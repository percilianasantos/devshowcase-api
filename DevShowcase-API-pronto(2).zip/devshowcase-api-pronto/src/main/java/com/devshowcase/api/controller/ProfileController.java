package com.devshowcase.api.controller;
import com.devshowcase.api.dto.*; import com.devshowcase.api.entity.Profile; import com.devshowcase.api.repository.ProfileRepository;
import jakarta.validation.Valid; import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/profiles")
public class ProfileController {
 private final ProfileRepository repo; public ProfileController(ProfileRepository repo){this.repo=repo;}
 @PostMapping @ResponseStatus(HttpStatus.CREATED) public ProfileResponse create(@Valid @RequestBody ProfileRequest r){Profile p=new Profile();p.setName(r.name());p.setEmail(r.email());p.setBio(r.bio());p=repo.save(p);return new ProfileResponse(p.getId(),p.getName(),p.getEmail(),p.getBio());}
 @GetMapping("/{id}") public ProfileResponse get(@PathVariable Long id){Profile p=repo.findById(id).orElseThrow(()->new RuntimeException("Perfil não encontrado"));return new ProfileResponse(p.getId(),p.getName(),p.getEmail(),p.getBio());}
}