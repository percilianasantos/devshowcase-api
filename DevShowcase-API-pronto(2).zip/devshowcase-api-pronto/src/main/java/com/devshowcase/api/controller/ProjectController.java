package com.devshowcase.api.controller;
import com.devshowcase.api.dto.*; import com.devshowcase.api.entity.*; import com.devshowcase.api.repository.*;
import jakarta.validation.Valid; import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/api/projects")
public class ProjectController {
 private final ProjectRepository projects; private final ProfileRepository profiles; private final TechnologyRepository technologies;
 public ProjectController(ProjectRepository p,ProfileRepository pr,TechnologyRepository t){projects=p;profiles=pr;technologies=t;}
 @PostMapping @ResponseStatus(HttpStatus.CREATED) public ProjectResponse create(@Valid @RequestBody ProjectRequest r){
  Profile profile=profiles.findById(r.profileId()).orElseThrow(()->new RuntimeException("Perfil não encontrado"));
  Project p=new Project();p.setTitle(r.title());p.setDescription(r.description());p.setUrl(r.url());p.setProfile(profile);
  p.setTechnologies(r.technologyIds()==null?List.of():technologies.findAllById(r.technologyIds()));p=projects.save(p);return out(p);
 }
 @GetMapping public List<ProjectResponse> all(){return projects.findAll().stream().map(this::out).toList();}
 private ProjectResponse out(Project p){return new ProjectResponse(p.getId(),p.getTitle(),p.getDescription(),p.getUrl(),p.getProfile().getId(),p.getTechnologies().stream().map(Technology::getId).toList());}
}