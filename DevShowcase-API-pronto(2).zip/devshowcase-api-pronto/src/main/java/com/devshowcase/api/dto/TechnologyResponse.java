package com.devshowcase.api.dto;
public record TechnologyResponse(Long id,String name) {}