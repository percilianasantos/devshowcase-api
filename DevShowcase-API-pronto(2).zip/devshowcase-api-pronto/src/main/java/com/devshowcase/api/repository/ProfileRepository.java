package com.devshowcase.api.repository;
import com.devshowcase.api.entity.Profile;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ProfileRepository extends JpaRepository<Profile, Long> {}
