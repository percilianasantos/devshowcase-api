package com.devshowcase.api.repository;
import com.devshowcase.api.entity.Feedback;
import org.springframework.data.jpa.repository.JpaRepository;
public interface FeedbackRepository extends JpaRepository<Feedback, Long> {}
