package com.devshowcase.api.controller;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.MethodArgumentNotValidException; import org.springframework.web.bind.annotation.*; import java.util.*;
@RestControllerAdvice
public class ApiExceptionHandler {
 @ExceptionHandler(MethodArgumentNotValidException.class) @ResponseStatus(HttpStatus.BAD_REQUEST)
 public Map<String,String> validation(MethodArgumentNotValidException e){Map<String,String> m=new HashMap<>();e.getBindingResult().getFieldErrors().forEach(x->m.put(x.getField(),x.getDefaultMessage()));return m;}
 @ExceptionHandler(RuntimeException.class) @ResponseStatus(HttpStatus.NOT_FOUND)
 public Map<String,String> error(RuntimeException e){return Map.of("erro",e.getMessage());}
}