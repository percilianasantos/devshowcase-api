# DevShowcase API

API REST da atividade de Modelagem de domínio, persistência e endpoints básicos.

Tecnologias: Java 17, Spring Boot 4.0.8, Spring Web, Spring Data JPA, Validation e H2.

## Executar
`./mvnw spring-boot:run`

Windows: `mvnw.cmd spring-boot:run`

Servidor: http://localhost:8080

## Endpoints
POST /api/profiles
GET /api/profiles/{id}
POST /api/technologies
GET /api/technologies
POST /api/projects
GET /api/projects

## Exemplos Postman

Perfil:
{"name":"Evangelista Generosa dos Santos","email":"evangelista@example.com","bio":"Estudante de Tecnologia em Sistemas para Internet."}

Tecnologia:
{"name":"Java"}

Projeto:
{"title":"DevShowcase API","description":"API REST para apresentação de projetos.","url":"https://github.com/","profileId":1,"technologyIds":[1]}
